#' Student Depression Dataset
#'
#' A dataset containing the information about Indian students' demographics, academic indicators, lifestyle factors, and their depression status.
#'
#' @format A data frame with 27901 rows and 18 variables:
#' \describe{
#'   \item{id}{Primary indentifier of each student. (numeric)}
#'   \item{Gender}{Student's gender. (character, "Male" or "Female")}
#'   \item{Age}{Student's of age. (character, "Yes" or "No"}
#'   \item{City}{Student's city of residence. (character)}
#'   \item{Profession}{Student's profession. (character)}
#'   \item{Academic.Pressure}{Level of academic pressure. (numeric, 0-5 scale)}
#'   \item{Work.Pressure}{Level of work pressure. (numeric, 0-5 scale)}
#'   \item{CGPA}{Cumulative Grade Point Average. (numeric, 0-10 scale)}
#'   \item{Study.Satisfaction}{Level of study satisfaction studies. (numeric, 0-5 scale)}
#'   \item{Job.Satisfaction}{Level of job satisfaction. (numeric, 0-5 scale)}
#'   \item{Sleep.Duration}{Average hours of sleep per night. (character) ("Less than 5 hours", "5-6 hours", "7-8 hours", "More than 8 hours", or "Others")}
#'   \item{Dietary.Habits}{Self perceived quality of dietary habits. (character) ("Healthy", "Moderate", "Unhealthy", or "Others")}
#'   \item{Degree}{Degree program. (character)}
#'   \item{Have.you.ever.had.suicidal.thoughts..}{Binary indicator of suicidal behavior. (numeric, 0 or 1)}
#'   \item{Work.Study.Hours}{Total hours spent on work/study per week. (numeric)}
#'   \item{Financial.Stress}{Level of financial stress. (numeric, 0-5 scale)}
#'   \item{Family.History.of.Mental.Illness}{Binary indicator of family mental health history. (character, "Yes" or "No")}
#'   \item{Depression}{Primary outcome variable of depression measure. (numeric, 0 or 1)}
#' }
#'
#' @source https://www.kaggle.com/datasets/adilshamim8/student-depression-dataset
#'
"student_depression_dataset"
